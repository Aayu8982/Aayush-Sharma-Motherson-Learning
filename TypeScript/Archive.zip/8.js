// TypeScript Type Aliases and Interfaces
var studentName = "Aayush Sharma";
var studentAge = 28;
var passoutYear = 2019;
var student = {
    name: studentName,
    age: studentAge,
    year: passoutYear,
};
console.log(student);
