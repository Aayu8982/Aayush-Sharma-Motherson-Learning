var a = 100;
var myName = "Aayush Sharma";
console.warn(a);
console.log(myName);
