// TypeScript Object Types
var employee = {
    name: 'Aayush Sharma',
    age: 34,
    hobbies: ['cricket', 'chess'],
};
employee.indian = false;
console.log(employee);
