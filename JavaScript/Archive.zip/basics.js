
// Text Change
function changeText() {
  document.getElementById("demo").innerHTML = "Company : Motherson Group";
  document.getElementById("demo").style.fontSize ="30px";
}

/*** JS Output */

// Window Prompt & Alert
// const name = window.prompt("Please enter your name")
// window.alert(`Welcome ${name}, Thanks for registering`)

// // console.log
// console.log("Welcome Aayush Sharma");


/** Statements */
// JS statements are composed of the Values, Operators, Expressions, Keywords, and Comments.

/** Variables */

// How to Create Variables
var a=10;
var b=10

// How to Use Variables
var c = a+b;
console.log(c);

// expression
var d = a + b * 10;
console.log(d);
console.log("Aayush"+" "+"Sharma");

//Comments 

// single line comment
/**
 * multi line comment
 */

