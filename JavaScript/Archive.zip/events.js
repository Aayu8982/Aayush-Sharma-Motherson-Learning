function changeText() {
    document.getElementById("demo").innerHTML = "Company : Motherson Group";
    document.getElementById("demo").style.fontSize ="30px";
  }
  