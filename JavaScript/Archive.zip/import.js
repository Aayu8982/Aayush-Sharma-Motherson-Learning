import { PI, sum } from "./export.js";

console.log(PI); // 3.14
console.log(sum(1, 2)); // 3
