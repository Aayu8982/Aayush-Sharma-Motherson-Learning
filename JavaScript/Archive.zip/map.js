let myMap = new Map();
myMap.set("name", "Aayush");
myMap.set("age", 30);
console.log(myMap.get("name")); // "Aayush"

let mySet = new Set();
mySet.add(1);
mySet.add(2);
mySet.add(1);

console.log(mySet); //[1,2]