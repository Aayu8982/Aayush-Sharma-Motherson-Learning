const letters = new Set();

letters.add("a");
letters.add("b");
letters.add("c");
letters.add("c");
letters.add("c");


console.log(letters);